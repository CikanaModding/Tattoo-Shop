fx_version 'cerulean'
games {'gta5'}

this_is_a_map 'yes'

shared_scripts {
	'init.lua'
}


Author 'CikanaModding'
description 'Redesigned Tattooshop'

version '1.0'

