WEITERGABE AN DRITTE NICHT ERLAUBT
SOLLTE MAN ETWAS ÄNDERN WOLLEN, SO IST EIN TICKET AUF UNSEREM DISCORD SERVER ZU ÖFFNEN


Falls du hilfe brauchst, oder etwas nicht funktioniert, kannst du dich gerne auf unserem Discord Server melden und ein Ticket öffnen.

Link: https://discord.gg/YkSq4yB8x3

DON'T GIVE THIS RESSOURCE TO SOMEONE ELSE
IF YOU WANT TO CHANGE SOMETHING, YOU HAVE TO JOIN OUR DISCORD SERVER AND ASK FOR PERMISSION

If you need help to stream your ressource or anything else, you can join our Discord Server and create a ticket.

https://discord.gg/YkSq4yB8x3