VERSION = GetResourceMetadata(GetCurrentResourceName(), 'version', 0)

print(
	"^0======================================================================^7\n" ..
	"^0[^4Author^0]^7 :^0 ^0CikanaModding^7\n" ..
	"^0[^3Version^0]^7 :^0 ^01.0^7\n" ..
	"^0[^2Store^0]^7 :^0 ^5https://store.cikana-modding.de^7\n" ..
	"^0[^1Discord^0]^7 :^0 ^5https://discord.gg/YkSq4yB8x3^7\n" ..
	"^0======================================================================^7"
)
